ESP8266 BOARD VERSION 2.4.7

Tutoriais
https://www.youtube.com/watch?v=GOiLbs5Sidc

https://mundoprojetado.com.br/acelerometro-mpu6050-arduino/

https://blog.eletrogate.com/economizando-energia-sleep-modes-no-esp8266/

